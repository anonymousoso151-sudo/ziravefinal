module.exports = {
  dependencies: {
    'react-native-vector-icons': {
      platforms: {
        ios: {
          xcodeprojPath: 'ios/ZiraveApp.xcodeproj',
          plistPath: 'ios/ZiraveApp/Info.plist',
        },
      },
    },
  },
};